This is empty project file structure for quick start with webJS pages.
If you want to use it for serious things, you will need node (http://nodejs.org/) platform to run build.sh script.
If you just want to try it in "browser based mode" for fun or development reasons, you don't need to run build.sh
and you don't need any node platform. Just open the "source/index.html" file in your browser and see.

