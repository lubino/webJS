define(['parse','web/Components'], function (parse, Components) {
    return parse('main.html');
});