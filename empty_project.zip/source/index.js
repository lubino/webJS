require(['main'], function (main) {
    main();
});