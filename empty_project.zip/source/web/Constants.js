define([], function () {

    return {
        loadingComponent: "loadingWebComponent",
        author: "Lubos Strapko"
    };
});